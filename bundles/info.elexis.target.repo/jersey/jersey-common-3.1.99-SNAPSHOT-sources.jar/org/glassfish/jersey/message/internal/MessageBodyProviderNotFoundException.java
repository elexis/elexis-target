/*
 * Copyright (c) 2012, 2020 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0, which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the
 * Eclipse Public License v. 2.0 are satisfied: GNU General Public License,
 * version 2 with the GNU Classpath Exception, which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 */

package org.glassfish.jersey.message.internal;

import jakarta.ws.rs.ProcessingException;

/**
 * Jersey processing exception signaling that no appropriate MessageBodyReader or MessageBodyWriter was found.
 *
 * @author Miroslav Fuksa
 */
public class MessageBodyProviderNotFoundException extends ProcessingException {

    private static final long serialVersionUID = 2093175681702118380L;

    public MessageBodyProviderNotFoundException(Throwable cause) {
        super(cause);
    }

    public MessageBodyProviderNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public MessageBodyProviderNotFoundException(String message) {
        super(message);
    }
}
